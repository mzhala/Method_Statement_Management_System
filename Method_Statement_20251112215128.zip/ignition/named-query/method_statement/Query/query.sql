INSERT INTO  tasks(task_description, user_username, statement_id)
VALUES('Entry into site.
All personnel to be inducted
Sign on Permit
Toolbox Talks (DSTI, TSTI, etc.)', 
	'admin', 	4)	


