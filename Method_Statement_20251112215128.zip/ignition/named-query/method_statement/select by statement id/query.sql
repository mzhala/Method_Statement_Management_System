SELECT ms.*,
       sal.location_name,
       s.site_name
FROM method_statement ms
JOIN site_activity_location sal
  ON ms.activity_location_id = sal.activity_location_id
JOIN site s
  ON sal.site_id = s.site_id
  WHERE ms.statement_id = :statement_id;
