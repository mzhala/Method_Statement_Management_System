SELECT statement_id
FROM method_statement
ORDER BY statement_id DESC
LIMIT 1;
