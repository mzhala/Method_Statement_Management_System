SELECT distinct  work_activity 
FROM method_statement 
ORDER By work_activity DESC