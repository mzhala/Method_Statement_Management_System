--drop table method_statements;
CREATE TABLE method_statements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date_created TEXT DEFAULT (datetime('now')),
    site TEXT NOT NULL,
    work_activity TEXT NOT NULL,
    activity_location TEXT NOT NULL,
    activity_start_date TEXT NOT NULL,
    activity_end_date TEXT NOT NULL,
    worker_signatures_required INTEGER NOT NULL,
    workers_signed INTEGER DEFAULT 0,
    status text default 'Pending'
);
