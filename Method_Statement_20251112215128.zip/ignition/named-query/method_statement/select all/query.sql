SELECT 
    ms.*,
    sal.location_name,
    s.site_name,
    CASE
        WHEN sf.statement_id IS NULL THEN 'Awaiting Supervisor Feedback'
        WHEN sf.supervisor_rejected = true THEN 'Supervisor Rejected'
        WHEN EXISTS (
            SELECT 1 
            FROM tasks t
            WHERE t.statement_id = ms.statement_id
              AND (t.task_completed = false OR t.task_closed = false)
        ) THEN 'Open'
        ELSE 'Closed'
    END AS status,
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM method_statement_workers mw
            WHERE mw.statement_id = ms.statement_id
              AND mw.username = :username
        ) THEN true
        ELSE false
    END AS required
FROM method_statement ms
JOIN site_activity_location sal
  ON ms.activity_location_id = sal.activity_location_id
JOIN site s
  ON sal.site_id = s.site_id
LEFT JOIN (
    SELECT sf1.*
    FROM supervisor_feedback sf1
    WHERE sf1.time_stamp  = (
        SELECT MAX(sf2.time_stamp)
        FROM supervisor_feedback sf2
        WHERE sf2.statement_id = sf1.statement_id
    )
) sf ON sf.statement_id = ms.statement_id;
