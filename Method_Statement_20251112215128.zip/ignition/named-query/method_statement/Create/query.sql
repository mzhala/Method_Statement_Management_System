--drop table method_statement;
create table method_statement (
    statement_id integer primary key autoincrement,
    work_activity text,
    start_date DATETIME,
    end_date DATETIME,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    activity_location_id integer not null,
    initiator_username text not null,
    initiator_name text,
    initiator_surname text,
    foreign key (activity_location_id) references site_activity_location(activity_location_id)
);