--drop table method_statement_workers
create table method_statement_workers (
    worker_id integer primary key autoincrement,
    username text,
    name text,
    surname text,
    role text,
    signed Boolean DEFAULT 0,
    signed_time_stamp DATETIME,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    statement_id integer not null,
    foreign key (statement_id) references method_statement(statement_id)
);