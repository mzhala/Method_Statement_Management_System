SELECT *
FROM method_statement_workers 
WHERE statement_id = :statement_id 