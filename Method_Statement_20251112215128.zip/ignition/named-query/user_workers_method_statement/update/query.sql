UPDATE method_statement_workers 
SET  signed = 1,
 signed_time_stamp = datetime('now')
WHERE  worker_id = :worker_id