INSERT INTO method_statement_workers(username, name, surname,  statement_id)
VALUES(:username, :name, :surname,  :statement_id)


