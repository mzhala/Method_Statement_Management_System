--drop table tool_inventory
create table tool_inventory (
    tool_id integer primary key autoincrement,
    tool_name text,
    brand text,
    size text,
    quantity integer,
    available integer,
    under_maintenance integer,
    checked_out integer,
    lost integer,
	time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP
);