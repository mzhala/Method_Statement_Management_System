SELECT DISTINCT brand   FROM tool_inventory
WHERE brand != ''
ORDER BY brand