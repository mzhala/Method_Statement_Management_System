SELECT
    ti.tool_id,
    ti.tool_name,
    ti.quantity
        - COALESCE(SUM(msti.borrowed_quantity 
            - COALESCE(msti.returned_good_condition, 0) 
            - COALESCE(msti.returned_damaged, 0) 
            - COALESCE(msti.returned_lost, 0)), 0)
        - COALESCE(SUM(msti.returned_damaged), 0)
        - COALESCE(SUM(msti.returned_lost), 0) AS calc_available
FROM tool_inventory ti
LEFT JOIN method_statement_tool_inventory msti
    ON msti.tool_id = ti.tool_id
GROUP BY 
    ti.tool_id,
    ti.tool_name,
    ti.quantity
HAVING calc_available > 0
ORDER BY ti.tool_name;
