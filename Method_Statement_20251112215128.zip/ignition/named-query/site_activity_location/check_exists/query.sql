SELECT EXISTS(
    SELECT 1
    FROM  site_activity_location 
    WHERE site_id  = :site_id AND location_name = :location_name
);
