SELECT activity_location_id 
FROM   site_activity_location 
WHERE  site_id = :site_id  AND location_name = :location_name