INSERT INTO  site_activity_location   (site_id , location_name )
VALUES (:site_id , :location_name);