--drop table site_activity_location;
create table site_activity_location (
    activity_location_id integer primary key autoincrement,
    location_name text not null,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    site_id integer not null,
    foreign key (site_id) references site(site_id)
);