SELECT location_name FROM site_activity_location
WHERE site_id = :site_id