--drop table method_statement_ppe_inventory;
create table method_statement_ppe_inventory (
    mspi_id integer primary key autoincrement,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    ppe_id integer not null,
    statement_id integer not null,
    foreign key (ppe_id) references ppe_inventory(ppe_id),
    foreign key (statement_id) references method_statement(statement_id)
);