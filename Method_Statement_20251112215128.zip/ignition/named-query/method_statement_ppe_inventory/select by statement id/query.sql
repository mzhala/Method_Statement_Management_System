SELECT t1.*, t2.ppe_name 
FROM method_statement_ppe_inventory t1
LEFT JOIN  ppe_inventory t2 ON t1.ppe_id = t2.ppe_id 
WHERE statement_id = :statement_id AND t2.ppe_name != ''