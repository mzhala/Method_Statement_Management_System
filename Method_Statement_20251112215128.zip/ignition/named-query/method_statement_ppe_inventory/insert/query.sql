INSERT INTO  method_statement_ppe_inventory (ppe_id,  statement_id )
VALUES (:ppe_id, :statement_id)