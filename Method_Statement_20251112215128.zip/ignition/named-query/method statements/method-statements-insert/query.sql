INSERT INTO method_statements (
    site, activity_location, work_activity, activity_start_date, activity_end_date,
    supervisor_approved, worker_signatures_required, workers_signed, status
) VALUES
('Site A', 'Warehouse Extension', 'Structural steel installation', '2025-06-01', '2025-06-10', 1, 5, 5, 'Pending'),
('Site B', 'Parking Lot', 'Excavation and trenching', '2025-06-05', '2025-06-08', 1, 4, 4, 'Completed'),
('Site C', 'Office Block', 'Internal electrical wiring', '2025-06-03', '2025-06-07', 0, 3, 1, 'Pending'),
('Site A', 'Residential Units', 'Scaffolding erection', '2025-06-09', '2025-06-09', 1, 6, 6, 'Completed'),
('Site E', 'Factory Floor', 'Concrete pouring', '2025-06-02', '2025-06-03', 0, 5, 0, 'Pending'),
('Site A', 'Storage Facility', 'Roof sheeting installation', '2025-06-04', '2025-06-06', 1, 4, 4, 'Completed'),
('Site G', 'Underground Parking', 'Formwork setup', '2025-06-07', '2025-06-10', 1, 7, 2, 'Pending'),
('Site H', 'Commercial Complex', 'Tiling and finishing', '2025-06-11', '2025-06-13', 1, 2, 2, 'Active'),
('Site I', 'Admin Building', 'HVAC duct installation', '2025-06-05', '2025-06-09', 1, 3, 3, 'Active'),
('Site J', 'Training Center', 'Painting and sealing', '2025-06-10', '2025-06-12', 1, 3, 3, 'Rejected');
