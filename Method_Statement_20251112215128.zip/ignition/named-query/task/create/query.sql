--drop table tasks;
create table tasks (
    task_id integer primary key autoincrement,
    task_description text,
    task_open boolean default 1,
    task_completed boolean default 0, 
    task_closed boolean default 0,
    reason_closed text,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    statement_id integer not null,
    user_username text not null,
    user_name text,
    user_surname text,
    foreign key (statement_id) references method_statement(statement_id)
);