INSERT INTO tasks ( statement_id ,  task_description ,  user_username ,  user_name ,  user_surname )
VALUES( :statement_id ,  :task_description ,  :user_username ,  :user_name ,  :user_surname )