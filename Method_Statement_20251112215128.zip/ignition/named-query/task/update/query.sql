UPDATE  tasks 
SET  
task_completed  = :task_completed,
task_closed = :task_closed, 
  reason_closed  = :reason_closed
WHERE task_id = :task_id
