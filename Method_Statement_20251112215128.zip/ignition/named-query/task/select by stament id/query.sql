SELECT
    ROW_NUMBER() OVER (ORDER BY t.task_id) AS counter,
    t.task_description,
    t.task_completed,
    t.task_closed,
    t.reason_closed,
    t.time_stamp,
    t.task_id,
    CASE
        WHEN t.task_completed = true THEN 0
        WHEN t.task_closed = true THEN 1
        ELSE NULL
    END AS status
FROM tasks t
INNER JOIN (
    SELECT task_description, MAX(time_stamp) AS max_stamp
    FROM tasks
    WHERE statement_id = :statement_id
    GROUP BY task_description
) latest
ON t.task_description = latest.task_description
AND t.time_stamp = latest.max_stamp
WHERE t.statement_id = :statement_id
ORDER BY t.task_id;
