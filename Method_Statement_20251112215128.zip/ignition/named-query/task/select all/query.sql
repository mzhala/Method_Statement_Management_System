SELECT  task_description  FROM tasks
ORDER BY task_description