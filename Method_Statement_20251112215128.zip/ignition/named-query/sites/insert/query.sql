INSERT INTO  site ( site_name )
VALUES (:site_name);