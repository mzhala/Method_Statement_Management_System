SELECT EXISTS(
    SELECT 1
    FROM site
    WHERE site_name = :site_name
);
