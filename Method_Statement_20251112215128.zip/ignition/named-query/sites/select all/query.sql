SELECT site_id, site_name FROM site
ORDER BY site_name;