--drop table site;
create table site (
    site_id integer primary key autoincrement,
    site_name text not null,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP
);