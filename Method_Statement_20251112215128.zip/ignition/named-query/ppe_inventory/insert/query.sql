INSERT INTO  ppe_inventory ( ppe_name )
VALUES (:ppe_name)