INSERT INTO ppe_inventory (ppe_name, ppe_description) VALUES
('Hard Hat', 'Protective helmet to prevent head injuries from falling objects.'),
('Safety Glasses', 'Impact-resistant glasses to protect eyes from debris and dust.'),
('Ear Plugs', 'Disposable ear plugs to protect hearing from loud noises.'),
('Safety Gloves', 'Gloves made of durable material to protect hands from cuts and chemicals.'),
('High-Visibility Vest', 'Bright reflective vest to increase visibility in low light.'),
('Respirator Mask', 'Mask designed to filter harmful dust, fumes, and gases.'),
('Steel-Toe Boots', 'Protective footwear with reinforced toes to prevent foot injuries.'),
('Face Shield', 'Clear shield to protect face from splashes and flying particles.'),
('Coveralls', 'Full-body protective clothing to prevent contamination and dirt.'),
('Knee Pads', 'Protective pads worn on knees to reduce injury when kneeling.');
