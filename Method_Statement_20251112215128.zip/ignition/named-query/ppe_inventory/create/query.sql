--drop table ppe_inventory;
create table ppe_inventory (
    ppe_id integer primary key autoincrement,
    ppe_name text,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP
);