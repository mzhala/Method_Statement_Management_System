SELECT EXISTS(
    SELECT 1
    FROM ppe_inventory 
    WHERE ppe_name  = :ppe_name 
);
