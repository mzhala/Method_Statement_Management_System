SELECT ppe_id 
FROM   ppe_inventory  
WHERE   ppe_name = :ppe_name