select ppe_id,  ppe_name
from  ppe_inventory;