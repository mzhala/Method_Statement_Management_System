SELECT * 
FROM method_statement_tool_inventory
WHERE statement_id = :statement_id
  AND tool_supervisor_status = 0
  AND borrowed_quantity = (
        COALESCE(returned_good_condition, 0) 
      + COALESCE(returned_damaged, 0) 
      + COALESCE(returned_lost, 0)
  );
