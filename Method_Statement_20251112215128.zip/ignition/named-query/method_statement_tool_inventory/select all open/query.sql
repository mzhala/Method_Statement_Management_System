SELECT * FROM method_statement_tool_inventory
WHERE  tool_supervisor_status = 0
ORDER BY  msti_id asc