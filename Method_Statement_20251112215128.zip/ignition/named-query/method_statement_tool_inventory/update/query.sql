UPDATE  method_statement_tool_inventory 
SET  
returned_good_condition  = :returned_good_condition,
returned_damaged 			= :returned_damaged,
returned_damaged_reason  = :returned_damaged_reason,
returned_lost 			= :returned_lost,
returned_lost_reason 	= :returned_lost_reason,
tool_supervisor_status  = 0
WHERE  msti_id = :msti_id