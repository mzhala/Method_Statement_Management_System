UPDATE method_statement_tool_inventory 
SET  
tool_supervisor_status = :tool_supervisor_status,
tool_supervisor_comment = :tool_supervisor_comment,
user_username 	= :user_username,
user_name		= :user_name,
user_surname 	= :user_surname
WHERE  msti_id = :msti_id;
