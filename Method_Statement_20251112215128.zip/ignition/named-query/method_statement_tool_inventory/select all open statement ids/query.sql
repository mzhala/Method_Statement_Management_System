SELECT DISTINCT statement_id
FROM method_statement_tool_inventory
WHERE 
    tool_supervisor_status = 0
    AND borrowed_quantity = (returned_good_condition + returned_damaged + returned_lost)
ORDER BY msti_id ASC;
