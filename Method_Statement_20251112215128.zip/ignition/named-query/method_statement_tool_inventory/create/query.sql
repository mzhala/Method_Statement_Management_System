--drop table method_statement_tool_inventory;
create table method_statement_tool_inventory (
    msti_id integer primary key autoincrement,
    borrowed_quantity integer,
    returned_good_condition integer default 0,
    returned_damaged integer default 0,
    returned_lost integer default 0, 
    tool_name text, 
    returned_damaged_reason text,
    returned_lost_reason text, 
    
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    statement_id integer not null,
    tool_id integer not null,
    user_username text not null,
    user_name text,
    user_surname text,
    foreign key (statement_id) references method_statement(statement_id),
    foreign key (tool_id) references tool_inventory(tool_id)
);