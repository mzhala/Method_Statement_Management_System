SELECT *
FROM method_statement_tool_inventory
WHERE msti_id = :msti_id 