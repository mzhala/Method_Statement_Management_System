SELECT *
FROM supervisor_feedback
WHERE statement_id = :statement_id
ORDER BY time_stamp DESC
LIMIT 1;
