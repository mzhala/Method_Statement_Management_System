--drop table supervisor_feedback;
create table supervisor_feedback (
    feedback_id integer primary key autoincrement,
    supervisor_approved BOOLEAN DEFAULT FALSE,
    supervisor_rejected BOOLEAN DEFAULT FALSE,
    supervisor_rejected_reason text,
    supervisor_username text,
    supervisor_name text,
    supervisor_surname text,
    time_stamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    statement_id INTEGER,
    foreign key (statement_id) references method_statements(statement_id)
);