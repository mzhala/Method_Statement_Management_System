INSERT INTO tool_inventory_old 
SELECT * FROM tool_inventory ;
