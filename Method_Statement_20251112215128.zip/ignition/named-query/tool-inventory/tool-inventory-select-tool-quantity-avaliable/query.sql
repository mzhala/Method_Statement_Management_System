select  quantity_available 
from  tool_inventory 
where  tool_id = :tool-id;