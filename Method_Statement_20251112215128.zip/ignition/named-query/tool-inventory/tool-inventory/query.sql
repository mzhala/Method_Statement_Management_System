--drop table tool__inventory;
CREATE TABLE tool_inventory_old (
    tool_id INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_name TEXT NOT NULL,
    brand TEXT,
    size TEXT,
    quantity_total INTEGER NOT NULL,
    quantity_available INTEGER NOT NULL,
    quantity_checked_out INTEGER NOT NULL DEFAULT 0,
    quantity_under_maintenance INTEGER NOT NULL DEFAULT 0,
    quantity_lost INTEGER NOT NULL DEFAULT 0

);


