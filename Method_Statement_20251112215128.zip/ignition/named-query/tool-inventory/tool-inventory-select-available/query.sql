select  tool_id ,  tool_name 
from  tool_inventory 
where  quantity_available > 0
order by tool_name;