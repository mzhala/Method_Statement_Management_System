select  *
from  tool_inventory 
where  quantity_available > 0
order by tool_id;