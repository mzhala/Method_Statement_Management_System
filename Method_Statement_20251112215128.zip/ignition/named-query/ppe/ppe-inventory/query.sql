CREATE TABLE ppe_inventory (
    ppe_id INTEGER PRIMARY KEY AUTOINCREMENT,
    ppe_name TEXT NOT NULL,
    description TEXT
);
