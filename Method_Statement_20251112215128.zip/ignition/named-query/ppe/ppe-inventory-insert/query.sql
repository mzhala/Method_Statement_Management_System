INSERT INTO ppe_inventory (ppe_name) VALUES
('Hard Hat'),
('Safety Glasses'),
('Ear Plugs'),
('Safety Gloves'),
('High-Visibility Vest'),
('Respirator Mask'),
('Steel-Toe Boots'),
('Face Shield'),
('Coveralls'),
('Knee Pads');
